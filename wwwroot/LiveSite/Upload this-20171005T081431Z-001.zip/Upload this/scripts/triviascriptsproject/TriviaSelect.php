<?php

	session_start();
	include('dbConnect.php');
	
	$pool = $_SESSION["question"];
	
	$sql = "select * from TriviaQuestions where questionPool = ?;";
	$stmt = sqlsrv_prepare( $conn, $sql, array( &$pool) );
	sqlsrv_execute($stmt);


	
	if( $stmt === false ) 
	{
		$resp->message = print_r( sqlsrv_errors(), true);
	}
		else
	{

		$rows = sqlsrv_has_rows( $stmt );
		if ($rows === true) 
		{
			
			$numQuestions = sqlsrv_num_rows( $stmt );			
			$selectedQuestion = rand(1, $numQuestions);
			

		$sql = "select * from TriviaQuestions where questionPool = ? and questionNum = ?;";
		$stmt = sqlsrv_prepare( $conn, $sql, array( &$pool, &$selectedQuestion ) );
		sqlsrv_execute($stmt);
		

		
		$row = sqlsrv_fetch_array($stmt);
		$questionNum = $row["questionNum"];
		$question = $row["question"];
		$options =  array($row["option1"],
						  $row["option2"],
						  $row["option3"],
						  $row["option4"],
						  $row["option5"],
						  $row["option6"]);

		
		$output = "<h2>Question " . $pool . ":</h2>";
		$output .= "<p>" . $question . "</p>";
		$output .= "<ul>";
		$count = count($options);
		for ($i = 0; $i < $count; $i++) 
		{
			$output .= "<li><input type='radio' name='answer' value='";
			$output .= $i . "' />" . $options[$i] . "</li>";
		}
		$output .= "</ul>";
		
		echo $output;
		//echo "<script language='JavaScript'>";
		//echo "document.getElementById('question').innerHTML = '" . $output ."';";
		//echo "</script>";
		
		
		
		}
	}
?>